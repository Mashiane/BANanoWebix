<?php
if (isset($_FILES['uploader'])) {
    // Example:
    if(move_uploaded_file($_FILES['uploader']['tmp_name'], "./assets/" . $_FILES['uploader']['name'])){
        echo '{ "status": "server" }';
    } else {
        echo '{ "status": "error" }';
    }
    exit;
} else {
    echo '{ "status": "isset error" }';
}
?>