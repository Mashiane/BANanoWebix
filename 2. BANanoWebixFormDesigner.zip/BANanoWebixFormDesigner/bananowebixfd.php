<?php header("Access-Control-Allow-Origin: *");$rest_json = file_get_contents("php://input");$_POST = json_decode($rest_json, true);$request='';if(isset($_POST['request'])){$request = $_POST['request'];$params = $_POST['params'];}if (!function_exists($request)) die("invalid request: '" . $request . "'"); 
function SendEmail($from,$to,$cc,$subject,$msg) {  
	$msg = str_replace("\n.", "\n..", $msg);  
	// use wordwrap() if lines are longer than 70 characters  
	$msg = wordwrap($msg,70,"\r\n");  
	//define from header  
	$headers = "From:" . $from . "\r\n";  
	$headers .= "Cc: " . $cc . "\r\n";  
	$headers .= "X-Mailer:PHP/" . phpversion();  
	// send email  
	$response = (mail($to,$subject,$msg,$headers)) ? "success" : "failure";  
    $output = json_encode(array("response" => $response));  
    header('content-type: application/json; charset=utf-8');  
    echo($output);  
}  
 
function prepareStatement($conn,$sql, $types, $values) { 
	//paramater types to execute 
	/* Bind parameters. Types: s = string, i = integer, d = double,  b = blob */ 
	$a_params = array(); 
	$param_type = ''; 
	$n = count($types); 
	for($i = 0; $i < $n; $i++) { 
		$param_type .= $types[$i]; 
	} 
	$a_params[] = & $param_type; 
	//values to execute 
	for($i = 0; $i < $n; $i++) { 
		$a_params[] = & $values[$i]; 
	} 
	/* Prepare statement */ 
	$stmt = $conn->prepare($sql); 
	if($stmt === false) { 
		$response = $conn->error; 
		$output = json_encode(array("response" => $response)); 
    	die($output); 
	} 
	/* use call_user_func_array, as $stmt->bind_param('s', $param); does not accept params array */ 
	call_user_func_array(array($stmt, 'bind_param'), $a_params); 
	return $stmt; 
} 
 
//update the connection settings with your own settings 
function BANanoMySQL($data) { 
	//define these so that they cannot be changed 
	require_once 'config.php'; 
	//set the header 
	header('content-type: application/json; charset=utf-8'); 
	//connect To MySQL 
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME); 
	//we cannot connect Return an error 
	If ($conn->connect_error) { 
		$response = $conn->connect_error; 
    	$output = json_encode(Array("response" => $response)); 
    	die($output); 
	} 
	mysqli_set_charset($conn, 'utf8'); 
	//data Is json, set it As a php variable 
	$data = json_decode($data, true); 
	//get the command To execute 
	$command = $data["command"]; 
	$sql = $data["sql"]; 
	$values = $data["args"]; 
	$types = $data["types"]; 
	$sql = mysqli_real_escape_string($conn, $sql); 
	Try { 
	$conn->autocommit(False); 
	//process the commands 
	switch($command){ 
		Case "select": 
			$result = $conn->query($sql); 
			If (!$result){ 
				$response = $conn->error; 
				$output = json_encode(Array("response" => $response)); 
				die($output); 
			} 
			// Fetch all 
			$rows = Array(); 
			While ($row = $result->fetch_assoc()) { 
				$rows[] = $row; 
			} 
			$output = json_encode(array("response" => "OK", "data" => $rows)); 
			break; 
		case "deletewhere": 
			//build the prepared statement 
			$stmt = prepareStatement($conn, $sql, $types, $values); 
			/* Execute statement */ 
			$result = $stmt->execute(); 
			if ($result){ 
				//get affected rows 
    			$affRows = $conn->affected_rows; 
				//the response should be ok 
				$output = json_encode(array("response" => "OK", "data" => $affRows)); 
			} else { 
				$response = $conn->error; 
				$output = json_encode(array("response" => $response)); 
			} 
			break; 
		case "updatewhere": 
			$stmt = prepareStatement($conn, $sql, $types, $values); 
			/* Execute statement */ 
			$result = $stmt->execute(); 
			if ($result){ 
				//get affected rows 
    			$affRows = $conn->affected_rows; 
				//the response should be ok 
				$output = json_encode(array("response" => "OK", "data" => $affRows)); 
			} else { 
				$response = $conn->error; 
				$output = json_encode(array("response" => $response)); 
			} 
			break; 
		case "update": 
			$stmt = prepareStatement($conn, $sql, $types, $values); 
			$result = $stmt->execute(); 
			if ($result){ 
				//get affected rows 
    			$affRows = $conn->affected_rows; 
				//the response should be ok 
				$output = json_encode(array("response" => "OK", "data" => $affRows)); 
			} else { 
				$response = $conn->error; 
				$output = json_encode(array("response" => $response)); 
			} 
			break; 
		case "selectwhere": 
			$stmt = prepareStatement($conn, $sql, $types, $values); 
			/* Execute statement */ 
			$result = $stmt->execute(); 
			if ($result) { 
				// Fetch all 
				$result = $stmt->get_result(); 
				$rows = array(); 
				while ($row = $result->fetch_assoc()) { 
					$rows[] = $row; 
				} 
				$output = json_encode(array("response" => "OK", "data" => $rows)); 
			} else { 
				$response = $conn->error; 
				$output = json_encode(array("response" => $response)); 
			} 
			break; 
		case "insert": 
			$stmt = prepareStatement($conn, $sql, $types, $values); 
			/* Execute statement */ 
			$result = $stmt->execute(); 
			if ($result) { 
				//get last insert id 
    			$lastId = $conn->insert_id; 
				//get affected rows 
    			//$affRows = $conn->affected_rows; 
				//the response should be ok 
				$output = json_encode(array("response" => "OK", "data" => $lastId)); 
			} else { 
				$response = $conn->error; 
				$output = json_encode(array("response" => $response)); 
			} 
			break; 
		default: 
			if ($conn->query($sql) === TRUE) { 
				$response = "OK"; 
			} else { 
				$response = $conn->error; 
			} 
			$output = json_encode(array("response" => $response)); 
			break; 
	} 
		echo($output); 
		$conn->close(); 
	} catch(Exception $e) { 
		$conn->rollback(); 
  		throw $e; 
	} 
} 
 
function preparesqlite($db, $sql, $types, $values) { 
		/* Bind parameters. Types: s = string, i = integer, d = double,  b = blob */ 
		$stmt = $db->prepare($sql); 
		if(is_array($types)){ 
			$n = count($types); 
			for($i = 0; $i < $n; $i++) { 
				$param_type = $types[$i]; 
				$param_value = $values[$i]; 
				$loc = $i + 1; 
				switch($param_type){ 
					case "s": 
						$stmt->bindValue($loc, $param_value, SQLITE3_TEXT); 
						break; 
					case "i": 
						$stmt->bindValue($loc, $param_value, SQLITE3_INTEGER); 
						break; 
					case "d": 
						$stmt->bindValue($loc, $param_value, SQLITE3_FLOAT); 
						break; 
					case "b": 
						$stmt->bindValue($loc, $param_value, SQLITE3_BLOB); 
						break; 
				} 
			} 
		} 
		return $stmt; 
} 
 
function BANanoSQLite($dbname,$data) { 
   	$db; 
	//set the header 
	header('content-type: application/json; charset=utf-8'); 
   	$db = new SQLite3($dbname, SQLITE3_OPEN_CREATE | SQLITE3_OPEN_READWRITE); 
	if(!$db) { 
  		$response = $db->lastErrorMsg(); 
  		$output = json_encode(Array("response" => $response)); 
  		die($output); 
	} 
	//data Is json, set it As a php variable 
	$data = json_decode($data, True); 
	//get the command To execute 
	$command = $data["command"]; 
	$sql = $data["sql"]; 
	$values = $data["args"]; 
	$types = $data["types"]; 
	switch($command){ 
		Case "select": 
		    $stmt = preparesqlite($db, $sql, $types, $values); 
			$res = $stmt->execute(); 
			$rows = Array(); 
			while($row = $res->fetchArray()) { 
				$rows[] = $row; 
			} 
			$res->finalize(); 
			$output = json_encode(array("response" => "OK", "data" => $rows)); 
	  		echo $output; 
			break; 
		case "deletewhere": 
			//build the prepared statement 
			$stmt = preparesqlite($db, $sql, $types, $values); 
			$db->exec('BEGIN'); 
			$res = $stmt->execute(); 
			$db->exec('COMMIT'); 
			$changes = $db->changes(); 
			$res = Array(); 
			$res[] = $changes; 
			$output = json_encode(array("response" => "OK", "data" => $res)); 
	  		echo $output; 
			break; 
	   	case "updatewhere": 
			//build the prepared statement 
			$stmt = preparesqlite($db, $sql, $types, $values); 
			$db->exec('BEGIN'); 
			$res = $stmt->execute(); 
			$db->exec('COMMIT'); 
			$changes = $db->changes(); 
			$res = Array(); 
			$res[] = $changes; 
			$output = json_encode(array("response" => "OK", "data" => $res)); 
	  		echo $output; 
			break; 
		case "selectwhere": 
			//build the prepared statement 
			$stmt = preparesqlite($db, $sql, $types, $values); 
			$res = $stmt->execute(); 
			$rows = Array(); 
			while($row = $res->fetchArray()) { 
				$rows[] = $row; 
			} 
			$res->finalize(); 
			$output = json_encode(array("response" => "OK", "data" => $rows)); 
	  		echo $output; 
			break; 
		case "replace": 
			$stmt = preparesqlite($db, $sql, $types, $values); 
			$db->exec('BEGIN'); 
			$res = $stmt->execute(); 
			$db->exec('COMMIT'); 
			$last_row_id = $db->lastInsertRowID(); 
			$res = Array(); 
			$res[] = $changes; 
			$output = json_encode(array("response" => "OK", "data" => $res)); 
	  		echo $output; 
			break; 
		case "insert": 
			$stmt = preparesqlite($db, $sql, $types, $values); 
			$db->exec('BEGIN'); 
			$res = $stmt->execute(); 
			$db->exec('COMMIT'); 
			$last_row_id = $db->lastInsertRowID(); 
			$res = Array(); 
			$res[] = $last_row_id; 
			$output = json_encode(array("response" => "OK", "data" => $res)); 
	  		echo $output; 
			break; 
		default: 
		    $stmt = preparesqlite($db, $sql, $types, $values); 
			$res = $stmt->execute(); 
			$rows = Array(); 
			while($row = $res->fetchArray()) { 
				$rows[] = $row; 
			} 
			$res->finalize(); 
			$output = json_encode(array("response" => "OK", "data" => $rows)); 
	  		echo $output; 
			break; 
	} 
	$db->close(); 
} 
$values = array_values($params);call_user_func_array($request, $values);?>